spacodi.calc <-
function(sp_plot, phy = NULL, traits = NA, which.plots = NA){
	if(!is.na(which.plots)) sp_plot <- sp_plot[,which(names(sp_plot) %in% which.plots)] # eliminate certain plots, if desired
	if(!missing(phy) & !missing(traits)) stop("Please supply either a phylogeny or a trait matrix, but not both.")

	sp_plot <- as.matrix(sp_plot)
	plots   <- names(sp_plot)
	np      <- ncol(sp_plot)
	ns      <- nrow(sp_plot)  # how many spp
	
# generate the distance matrix to be used
	if(missing(traits)){ # distmat is phylogenetic: Bst
		if(!missing(phy)) distmat <- cophenetic(phy) else distmat <- matrix(1, ncol = ns, nrow = ns)
		diag(distmat) <- 0	
		dim <- nrow(distmat)
		out <- NA
		out <- .C("spacodi", 
				  np = as.integer(np),
				  ns = as.integer(ns),
				  sp_plot = as.double(as.vector(sp_plot)),
				  distmat = as.double(as.vector(as.matrix(distmat))),
				  abundtype = as.integer(2),
				  Ndclass = as.integer(0),
				  dclass = as.double(c(0,0)),
				  Ist = 0,
				  Pst = 0,
				  Bst = 0,
				  PIst = 0
				  )
		if(missing(phy)) return(out[8]) else return(out[8:11])
	} else { #distmat is trait-based: Tst
		out.list=list()
		for(tt in 1:ncol(traits)) {
			trait=data.frame(traits[,tt])
			row.names(trait)=row.names(traits)
			distmat <- as.matrix(dist(trait))
			dim <- nrow(distmat)
			out <- NA
			out <- .C("spacodi", 
					  np = as.integer(np),
					  ns = as.integer(ns),
					  sp_plot = as.double(as.vector(sp_plot)),
					  distmat = as.double(as.vector(as.matrix(distmat))),
					  abundtype = as.integer(2),
					  Ndclass = as.integer(0),
					  dclass = as.double(c(0,0)),
					  Ist = 0,
					  Pst = 0,
					  Bst = 0,
					  PIst = 0
					  )
			names(out)[9:11]=c("Tst", "T*st", "TAUst")
			out.list[[tt]]=out[8:11]
		}
		names(out.list)=names(traits)
		return(out.list)
	} 	
}

