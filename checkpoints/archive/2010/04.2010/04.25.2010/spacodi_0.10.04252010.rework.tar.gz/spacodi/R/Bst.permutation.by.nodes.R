Bst.permutation.by.nodes<-function(phy, sp_plot, n.rep=10, method="1s", parm=NULL, rand.test=TRUE, r.rep=10000) {
# parameter settings
	if(is.null(sp_plot) && is.null(phy)) {
		stop("Must supply both an sp_plot and tree.")
	}
	if(is.null(r.rep) && rand.test)stop("Must specify 'r.rep' if using the randomization test")

# tree checking
	if(any(attr(phy, "names")=="node.label"))phy$node.label=NULL
	
# get Bsts for nodes							# for empirical data plot
	o.foo=Bst.all.nodes(sp_plot=sp_plot, phy=phy, return.all=FALSE)
	o.orig=as.data.frame(o.foo)
	o=o.foo[,"Bst"]
	names(o)=o.foo[,"node.ID"]
	o=o[order(o)]
	n.o=names(o)
		
# BST PLOT: randomization
	r.out=array(dim=c(length(o), n.rep))		# for all randomization
	for(bb in 1:n.rep) {
		b.foo=as.data.frame(Bst.permutation(sp_plot=sp_plot, phy=phy, n.rep=1, method=method, parm=parm)[,,1])
		b.match=match(as.numeric(n.o), b.foo$node.ID)
		r.out[,bb]=as.numeric(b.foo[b.match,"Bst"])
	}
	
# dataset matching
	r.out=as.data.frame(r.out)
	row.names(r.out)=as.numeric(n.o)
	names(r.out)=paste("iter",seq(1:n.rep),sep="")
	match(as.numeric(o.orig$node.ID),as.numeric(row.names(r.out)))->orig.match
	r.out=r.out[orig.match,]
	
# randomization test
	rand.array=array(dim=c(nrow(o.orig),5))
	if(rand.test==TRUE) {
		for(node in 1:nrow(o.orig)) {
			obs=o.orig$Bst[node]
			nn=o.orig$node.ID[node]
			exp=r.out[node,which(!is.na(r.out[node,]))]
			rand.array[node,1]=ifelse(length(exp)>0, randomization.test(obs=obs,exp=exp, iter=r.rep), NA)
			rand.array[node,2]=nn
			rand.array[node,3]=obs
			rand.array[node,4]=ifelse(length(exp)>0, mean(exp), NA)
			rand.array[node,5]=length(exp)
		}
		r.test=as.data.frame(rand.array)
		names(r.test)=c("p.value","node.ID","obs.Bst","m.exp.Bst","valid.comparisons")
		Bst.out=list(o.orig, r.out, r.test)
		names(Bst.out)=c("observed.Bst","expected.Bst","randomization.test")
		return(Bst.out)
	} else {
		Bst.out=list(o.orig, r.out)
		names(Bst.out)=c("observed.Bst","expected.Bst")
		return(Bst.out)
	}
}