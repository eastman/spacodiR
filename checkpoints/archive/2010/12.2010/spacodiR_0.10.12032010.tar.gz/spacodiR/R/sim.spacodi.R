sim.spacodi <-
function(species=100, plots=30, missing.prop=0.6, mean.abund=15, lambda=1, mu=0, sim.tree=FALSE,...){
	require(TreeSim)
	l.data=species*plots
	nulls=round(l.data*missing.prop)
	non.nulls=l.data-nulls
	m.log=log(mean.abund)
	out <- as.data.frame(matrix(sample(c(round(rlnorm(n=non.nulls, meanlog=m.log)),rep(0,nulls))),species,plots))
	rownames(out) <- paste("sp",seq(1:species),sep="")
	names(out) <- paste("plot",seq(1:plots),sep="")
	if(sim.tree) {
		if(species<2)stop("Simulation called for a tree with fewer than two taxa.")
		phy=sim.bd.taxa(n=species, numbsim=1, lambda=lambda, mu=mu, complete=FALSE, ...)[[1]]
		phy$tip.label=row.names(out)
		res=list(out,phy)
		names(res)=c("sp.plot","sp.tree")
		return(res)
	} else {return(list(sp.plot=out))}
}

