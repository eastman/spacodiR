#determines if a value falls within a range [min,max]
#author: JM Eastman 2010

withinrange <-
function(x, min, max) {			 
	a=sign(x-min)
	b=sign(x-max)
	if(abs(a+b)==2) return(FALSE) else return(TRUE)
}


#general phylogenetic utility for returning the first (usually, unless a polytomy exists) two descendants the supplied node 
#author: JM EASTMAN 2010

get.desc.of.node <-
function(node, phy) {
	return(phy$edge[which(phy$edge[,1]==node),2])
}


#general phylogenetic utility for returning all descendants (listed as given in phy$edge[,2]) of a node (excluding the supplied node) 
#author: JM EASTMAN 2010

get.descendants.of.node <-
function(node, phy, tips=FALSE) {
	storage=list()
	if(is.null(node)) node=phy$edge[1,1]
	if(node%in%phy$edge[,1]) {
		desc=c(sapply(node, function(x) {return(phy$edge[which(phy$edge[,1]==x),2])}))
		while(any(desc%in%phy$edge[,1])) {
			desc.true=desc[which(desc%in%phy$edge[,1])]
			desc.desc=lapply(desc.true, function(x) return(get.desc.of.node(x, phy)))
			
			storage=list(storage,union(desc,desc.desc))
			
			desc=unlist(desc.desc)
		}
		storage=as.numeric(sort(unique(unlist(union(desc,storage)))))
	}
	if(tips) return(storage[storage<=Ntip(phy)]) else return(storage)
}



timemultifurcation=function(phy, time.range=c(0,0))
{
    if (is.null(phy$edge.length)) 
        stop("The tree does not appear to have branch lengths")
	if (class(phy)!="phylo") 
		stop("The tree does not appear to be a valid phylo object")
	if(length(time.range)>2)
		stop("Cannot interpret the range of time with more than two elements")
	if(length(time.range)==1)
		time.range=c(0,time.range)
	time.range=time.range[order(time.range)]
	bb <- branching.times(phy)
	inr=sapply(bb, function(x) withinrange(x, time.range[1], time.range[2]))
    ind <- as.numeric(names(bb[inr]))
	if(any(ind==Ntip(phy)+1)) ind=ind[-which(ind==Ntip(phy)+1)]
    n <- length(ind)
    if (!n) {
        return(phy)
	} else {
		ind.tmp = match(ind, phy$edge[,2])
		ind = ind.tmp[!is.na(ind.tmp)]
	}
	orig.edge=phy$edge
	orig.phy=phy
	ntips=Ntip(phy)
    reedge <- function(ancestor, des.to.drop) {
        wh <- which(phy$edge[, 1] == des.to.drop)
		dd <- which(orig.edge[, 2] == des.to.drop)
		dropped.branch <- phy$edge.length[dd]
		d.d <- c(get.desc.of.node(des.to.drop, orig.phy))
		if(length(d.d)) phy$edge.length[match(d.d, orig.edge[,2])]<<-phy$edge.length[match(d.d, orig.edge[,2])]+dropped.branch

        for (k in wh) {
            if (phy$edge[k, 2] %in% node.to.drop) {
                reedge(ancestor, phy$edge[k, 2])
            } else {
				phy$edge[k, 1] <<- ancestor
				
			}
        }
    }
		
    node.to.drop <- phy$edge[ind, 2]
    anc <- phy$edge[ind, 1]
    for (i in 1:n) {
        if (anc[i] %in% node.to.drop) 
            next
        reedge(anc[i], node.to.drop[i])
    }
    phy$edge <- phy$edge[-ind, ]
    phy$edge.length <- phy$edge.length[-ind]
    phy$Nnode <- phy$Nnode - n
    sel <- phy$edge > min(node.to.drop)
    for (i in which(sel)) phy$edge[i] <- phy$edge[i] - sum(node.to.drop < phy$edge[i])
    if (!is.null(phy$node.label)) 
        phy$node.label <- phy$node.label[-(node.to.drop - length(phy$tip.label))]
    phy
}