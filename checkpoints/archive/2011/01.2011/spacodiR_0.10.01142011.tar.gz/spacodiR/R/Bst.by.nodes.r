Bst.by.nodes<-function (sp.plot, phy, obs.only = FALSE, return.all = TRUE, 
n.rep = 10, method = "1s", parm = NULL, dmat = NULL, rand.test = TRUE, 
r.rep = 10000, ...) 
{
    sp.data = match.spacodi.data(sp.plot = sp.plot, phy = phy, ...)
    sp.plot = sp.data$sp.plot
    phy = sp.data$sp.tree
    if (is.null(sp.plot) && is.null(phy)) {
        stop("Must supply both an sp.plot and tree.")
    }
    if (is.null(r.rep) && rand.test) 
	stop("Must specify 'r.rep' if using the randomization test.")
    if (obs.only == TRUE) {
        rand.test = FALSE
        exp.Bst = FALSE
    }
    else {
        exp.Bst = TRUE
    }
    Bst.all.nodes <- function(sp.plot, phy, return.all = TRUE) {
        sub = subtrees(phy)
        n.nodes <- phy$Nnode
        out <- array(dim = c(length(sub), 4))
        for (i in 1:n.nodes) {
            node = min(sub[[i]]$node)
            time = max(branching.times(sub[[i]]))
            tips = length(sub[[i]]$tip.label)
            ss <- try(match.spacodi.data(sp.plot = sp.plot[rownames(sp.plot) %in% sub[[i]]$tip.label, ], phy = sub[[i]]),silent=TRUE)
			if(!inherits(ss,"try-error")) {
				sp.plot.i = ss$sp.plot
				sub.i = ss$sp.tree
				if (all(dim(sp.plot.i)) != 0 && length(sub.i$tip.label) >= 2) {
					Bst.i <- suppressWarnings(spacodi.calc(sp.plot = sp.plot.i, phy = sub[[i]], prune = TRUE))$Bst
				}
				else {
					Bst.i <- NaN
				}
			} else {
				Bst.i <- NaN
			}
            out[i, 1] <- Bst.i
            out[i, 2] <- tips
            out[i, 3] <- time
            out[i, 4] <- node
        }
        array.cols <- c("Bst", "tips", "node.time", "node.ID")
        dimnames(out) = list(NULL, array.cols)
        if (!return.all) {
            out = out[which(!is.na(out[, 1])), ]
        }
        return(out)
    }
    Bst.exp.nodes <- function(sp.plot, phy, n.rep = 10, method = "1s", 
							  parm = NULL, dmat = NULL) {
        sub = subtrees(phy)
        out <- array(dim = c(length(sub), 4, n.rep))
        if (method == "r.sp.plot") {
            for (j in 1:n.rep) {
                foo <- Bst.all.nodes(phy = phy, sp.plot = r.sp.plot(sp.plot, 
																	n.rep = 1)[[1]])
                out[, , j] <- foo
            }
        }
        else if (method == "1s") {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.1s(sp.plot))
            }
        }
        else if (method == "1a" && !is.null(parm$abund.class.ratio)) {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.1a(sp.plot, parm$abund.class.ratio))
            }
        }
        else if (method == "2s") {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.2s(sp.plot))
            }
        }
        else if (method == "2x" && !is.null(parm$level)) {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.2x(sp.plot, parm$level))
            }
        }
        else if (method == "3i") {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.3i(sp.plot))
            }
        }
        else if (method == "3t") {
            if (!is.null(dmat)) 
			dmat = dmat
            else dmat = NULL
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.3t(sp.plot, dmat))
            }
        }
        else if (method == "3x" && !is.null(parm$level)) {
            for (j in 1:n.rep) {
                out[, , j] <- foo <- Bst.all.nodes(phy = phy, 
												   sp.plot = resamp.3x(sp.plot, parm$level))
            }
        }
        else stop(cat("Unrecognized method declaration or insufficient information supplied:\n\tIs 'parm' set to a non-null value?\n\n"))
        dimnames(out) = list(NULL, names(as.data.frame(foo)), 
							 paste("iter", seq(1:n.rep), sep = "."))
        return(out)
    }
    o.foo = Bst.all.nodes(sp.plot = sp.plot, phy = phy, return.all = ifelse(obs.only == 
																			TRUE, TRUE, FALSE))
    o = o.foo[, "Bst"]
    names(o) = o.foo[, "node.ID"]
    o = o[order(o)]
    n.o = names(o)
    o.orig = as.data.frame(o.foo)
    row.names(o.orig) = o.orig$node.ID
    if (exp.Bst == TRUE) {
        ticker = c(1:35) * ceiling(n.rep/35)
        cat("\nSPACoDi calculations in progress:\n")
        e.out = array(dim = c(length(o), n.rep))
        for (bb in 1:n.rep) {
            b.foo = as.data.frame(Bst.exp.nodes(sp.plot = sp.plot, 
												phy = phy, n.rep = 1, method = method, parm = parm)[, 
								  , 1])
            b.match = match(as.numeric(n.o), b.foo$node.ID)
            e.out[, bb] = as.numeric(b.foo[b.match, "Bst"])
            if (bb %in% ticker) 
			cat(".")
        }
        cat("\n")
        e.out = as.data.frame(e.out)
        row.names(e.out) = as.numeric(n.o)
        names(e.out) = paste("iter", seq(1:n.rep), sep = "")
        orig.match <- match(as.numeric(o.orig$node.ID), as.numeric(row.names(e.out)))
        e.out = e.out[orig.match, ]
        if (rand.test == TRUE) {
            rand.array = array(dim = c(nrow(o.orig), 5))
            for (node in 1:nrow(o.orig)) {
                obs = o.orig$Bst[node]
                nn = o.orig$node.ID[node]
                exp = e.out[node, which(!is.na(e.out[node, ]))]
                rand.array[node, 1] = ifelse(length(exp) != 0, 
											 randomization.test.sp(obs = obs, exp = exp, 
																   iter = r.rep, two.tailed = TRUE)[[2]], 
											 NA)
                rand.array[node, 2] = nn
                rand.array[node, 3] = obs
                rand.array[node, 4] = ifelse(length(exp) != 0, 
											 mean(exp), NA)
                rand.array[node, 5] = length(exp)
            }
            r.test = as.data.frame(rand.array)
            names(r.test) = c("p.value", "node.ID", "obs.Bst", 
							  "m.exp.Bst", "valid.comparisons")
            row.names(r.test) = r.test$node.ID
            if (return.all == TRUE) {
                o.orig = as.data.frame(Bst.all.nodes(sp.plot = sp.plot, 
													 phy = phy, return.all = TRUE))
                row.names(o.orig) = o.orig$node.ID
            }
            else {
                o.orig = o.orig
            }
            Bst.out = list(o.orig, e.out, r.test)
            names(Bst.out) = c("observed.Bst", "expected.Bst", 
							   "randomization.test")
            return(Bst.out)
        }
        else {
            if (return.all == TRUE) {
                o.orig = as.data.frame(Bst.all.nodes(sp.plot = sp.plot, 
													 phy = phy, return.all = TRUE))
                row.names(o.orig) = o.orig$node.ID
            }
            else {
                o.orig = o.orig
            }
            Bst.out = list(o.orig, e.out)
            names(Bst.out) = c("observed.Bst", "expected.Bst")
            return(Bst.out)
        }
    }
    else {
        Bst.out = list(o.orig)
        names(Bst.out) = "observed.Bst"
        return(Bst.out)
    }
}