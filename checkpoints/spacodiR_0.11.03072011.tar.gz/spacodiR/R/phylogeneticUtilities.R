vmat <- function(phy){
	n=Ntip(phy)
	out <- .Call("vmat", tree=list(
								   ROOT = as.integer(n+1),
								   MAXNODE = as.integer(max(phy$edge[,1])),
								   ENDOFCLADE = as.integer(dim(phy$edge)[1]),
								   ANC = as.integer(phy$edge[,1]),
								   DES = as.integer(phy$edge[,2]),
								   EDGES = as.double(c(phy$edge.length,0)),
								   VCV = as.double(array(matrix(0, n, n)))),
				 PACKAGE = "spacodiR")
	v=matrix(out$VCV,nrow=n,byrow=FALSE)
	rownames(v)<-colnames(v)<-phy$tip.label
	return(v)
} 


cophen=function(phy){
	if(class(phy)=="phylo") {
		if(is.ultrametric(phy)) {	
			vmat=vmat(phy)
			cophen=2*(diag(vmat)-vmat)
		} else {
			cophen=cophenetic.phylo(phy)
		}
	} else {
		stop("phylogeny is not of class 'phylo'")
	}
	return(cophen)
}

#general statistical function for comparing two vectors on non-independent samples
#author: JM EASTMAN 2010; updated 03.06.2011 to remove NA

randomization.test.sp <-
function(obs=obs, exp=exp,  mu=0, iter=10000, two.tailed=FALSE, na.rm=TRUE){
	if(na.rm) {
		oe=lapply(list(obs,exp), function(x) return(x[!is.na(x)]))
		obs=oe[[1]]
		exp=oe[[2]]
	}
	O=as.numeric(obs)[sample(1:length(obs), iter, replace=TRUE)]
	E=as.numeric(exp)[sample(1:length(exp), iter, replace=TRUE)]
	
	result=c(O-(E+mu))
	p=round(sum(result>=0)/iter, digits=nchar(iter))
	q=1-p
	
	if(two.tailed) {
		res=list(diffs=result, 2*(c(p,q)[which(c(p,q)==min(c(p,q)))]))
	} else {
		res=list(diffs=result, greater=p, lesser=q)
	}
	return(res)
}



#determines if a value falls within a range [min,max]
#author: JM Eastman 2010

withinrange <-
function(x, min, max) {			 
	a=sign(x-min)
	b=sign(x-max)
	if(abs(a+b)==2) return(FALSE) else return(TRUE)
}


#general phylogenetic utility for returning the first (usually, unless a polytomy exists) two descendants the supplied node 
#author: JM EASTMAN 2010

get.desc.of.node <-
function(node, phy) {
	return(phy$edge[which(phy$edge[,1]==node),2])
}


#general phylogenetic utility for returning all descendants (listed as given in phy$edge[,2]) of a node (excluding the supplied node) 
#author: JM EASTMAN 2010

get.descendants.of.node <-
function(node, phy, tips=FALSE) {
	storage=list()
	if(is.null(node)) node=phy$edge[1,1]
	if(node%in%phy$edge[,1]) {
		desc=c(sapply(node, function(x) {return(phy$edge[which(phy$edge[,1]==x),2])}))
		while(any(desc%in%phy$edge[,1])) {
			desc.true=desc[which(desc%in%phy$edge[,1])]
			desc.desc=lapply(desc.true, function(x) return(get.desc.of.node(x, phy)))
			
			storage=list(storage,union(desc,desc.desc))
			
			desc=unlist(desc.desc)
		}
		storage=as.numeric(sort(unique(unlist(union(desc,storage)))))
	}
	if(tips) return(storage[storage<=Ntip(phy)]) else return(storage)
}


######
deresolve.phy=function(phy, time.range=c(0,0), relative=TRUE)
{
    if (is.null(phy$edge.length)) 
        stop("The tree does not appear to have branch lengths")
	if (class(phy)!="phylo") 
		stop("The tree does not appear to be a valid phylo object")
	if(length(time.range)>2)
		stop("Cannot interpret the range of time with more than two elements")
	if(length(time.range)==1)
		time.range=c(0,time.range)
	time.range=time.range[order(time.range)]
	bb <- branching.times(phy)
	if(relative) bb=bb/max(bb)
	inr=sapply(bb, function(x) withinrange(x, time.range[1], time.range[2]))
    ind <- as.numeric(names(bb[inr]))
	if(any(ind==Ntip(phy)+1)) ind=ind[-which(ind==Ntip(phy)+1)]
    n <- length(ind)
    if (!n) {
        return(phy)
	} else {
		ind.tmp = match(ind, phy$edge[,2])
		ind = ind.tmp[!is.na(ind.tmp)]
	}
	orig.edge=phy$edge
	orig.phy=phy
	ntips=Ntip(phy)
    reedge <- function(ancestor, des.to.drop) {
        wh <- which(phy$edge[, 1] == des.to.drop)
		dd <- which(orig.edge[, 2] == des.to.drop)
		dropped.branch <- phy$edge.length[dd]
		d.d <- c(get.desc.of.node(des.to.drop, orig.phy))
		if(length(d.d)) phy$edge.length[match(d.d, orig.edge[,2])]<<-phy$edge.length[match(d.d, orig.edge[,2])]+dropped.branch

        for (k in wh) {
            if (phy$edge[k, 2] %in% node.to.drop) {
                reedge(ancestor, phy$edge[k, 2])
            } else {
				phy$edge[k, 1] <<- ancestor
				
			}
        }
    }
		
    node.to.drop <- phy$edge[ind, 2]
    anc <- phy$edge[ind, 1]
    for (i in 1:n) {
        if (anc[i] %in% node.to.drop) 
            next
        reedge(anc[i], node.to.drop[i])
    }
    phy$edge <- phy$edge[-ind, ]
    phy$edge.length <- phy$edge.length[-ind]
    phy$Nnode <- phy$Nnode - n
    sel <- phy$edge > min(node.to.drop)
    for (i in which(sel)) phy$edge[i] <- phy$edge[i] - sum(node.to.drop < phy$edge[i])
    if (!is.null(phy$node.label)) 
        phy$node.label <- phy$node.label[-(node.to.drop - length(phy$tip.label))]
    phy
}


######
node.time.extractor <-
function(phy, start.time=0, stop.time=1, return.times=TRUE, proportion=TRUE, ape.ID=TRUE) {
	flag=FALSE
	if(!is.null(phy$node.label)) {
		nodes.orig=phy$node.label
		phy$node.label=NULL
		flag=TRUE
	} 
	xx = branching.times(phy)
	if (proportion && any(c(start.time, stop.time) > 1)) stop("Times do not appear to be proportions; at least one element exceeds 1.")
	if (proportion) times = c(start.time * max(xx), stop.time * max(xx)) else times = c(start.time, stop.time)
	stt = times[m <- which(c(start.time, stop.time) == min(c(start.time, stop.time)))]
	stp = times[-m]
	if (stp > max(xx)) {
		stp = max(xx)
		warning("Supplied time was not sensible: root age was substituted as a bound on the time-slice.")
	}
	new <- xx[which(xx <= stp)]
	old <- xx[which(xx >= stt)]
	nn <- as.numeric(intersect(names(new), names(old)))
	keep <- intersect(new, old)
	names(keep) = nn
	srt = sort(keep, decreasing = TRUE)
	if (return.times == TRUE) {
		if(flag && !ape.ID) {
			foo = list(nodes.orig[match(names(srt), names(xx))], unname(keep))
		} else {
			foo = list(as.numeric(names(srt)), unname(keep))
		}
		names(foo) = c("nodes", "times")
		return(foo)
	}
	else {
		if(flag && !ape.ID) {
			foo = nodes.orig[match(names(srt), names(xx))]
		} else {
			foo = as.numeric(names(srt))
		}
		return(foo)
	}
}


