write.spacodi.data <-
function(data, outfile){
	if(file.exists(outfile)){
		warning("Overwrote existing outfile.")
		unlink(outfile)
	}
	names=names(data)
	for(n in 1:length(names)){cat(c("\t",names[n]),file=outfile,append=T,sep="")}
	cat("\n",file=outfile,append=T,sep="")
	write.table(data,outfile,quote=F,col=F,append=T,sep="\t")
}

