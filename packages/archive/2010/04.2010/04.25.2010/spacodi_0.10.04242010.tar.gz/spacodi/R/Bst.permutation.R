Bst.permutation <-
function(sp_plot, phy, n.rep = 10, method="1s", parm=NULL, ...) {
# tree checking
	if(any(attr(phy, "names")=="node.label"))phy$node.label=NULL
	if(!is.binary.tree(phy)) {
		phy=multi2di(phy)
		warning("Supplied tree was not dichotomous and was randomly resolved with ape:::multi2di(). ") 
	}
	
	sub=subtrees(phy)
	n.plot=ncol(sp_plot)
	n.taxa=Ntip(phy)
	out <- array(dim=c(length(sub), 4, n.rep)) ### prep an output file
	if(method=="r.sp_plot"){
		for(j in 1:n.rep){
			foo <- Bst.all.nodes(phy = phy, sp_plot = r.sp_plot(sp_plot, n.rep=1)[[1]])
			out[,,j] <- foo
		}
	} else if(method=="1s"){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.1s(sp_plot))
		}
	} else if(method=="1a" && !is.null(parm$abund.class.ratio)){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.1a(sp_plot, parm$abund.class.ratio))
		}
	} else if(method=="2s"){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.2s(sp_plot))
		}
	} else if(method=="2x" && !is.null(parm$level)){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.2x(sp_plot, parm$level))
		}
	} else if(method=="3i"){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.3i(sp_plot))
		}
	} else if(method=="3t"){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.3t(sp_plot,...))
		}
	} else if(method=="3x" && !is.null(parm$level)){
		for(j in 1:n.rep){
			out[,,j] <- foo <- Bst.all.nodes(phy = phy, sp_plot = resamp.3x(sp_plot, parm$level))
		}
	} else stop(cat("Unrecognized method declaration or insufficient information supplied:\n\tIs 'parm' set to a non-null value?\n\n"))
	dimnames(out)=list(NULL, names(as.data.frame(foo)), paste("iter",seq(1:n.rep),sep="."))
	return(out)
}

