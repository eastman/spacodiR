spacodi.matrices<-function(sp_plot, phy) {
	orig=names(sp_plot)
	l.spp=nrow(sp_plot)
	drop.plots=vector()
	for(sp in 1:ncol(sp_plot)) {
		l.nulls=length(which(sp_plot[,sp]==0))
		if((l.spp-l.nulls)<2) {
			drop.plots=cbind(drop.plots, sp)
		}
	}
	
	if(length(drop.plots)!=0) {
		sp_plot=sp_plot[,-drop.plots[!is.na(drop.plots)]]
		warning("At least one plot was pruned from the matrix, there being fewer than two species sampled therein.")
	}
	
# tree checking
	if(any(attr(phy, "names")=="node.label"))phy$node.label=NULL
	if(!is.binary.tree(phy)) {
		phy=multi2di(phy)
		warning("Supplied tree was not dichotomous and was randomly resolved with ape:::multi2di(). ") 
	}
	
	plots=names(sp_plot)
	l.plots=length(plots)
	sp.array=array(dim=c(l.plots, l.plots, 4))
	out.array=array(dim=c(l.plots, 1, 4))
	r.out=list()
	cat("\npairwise SPACoDi calculations in progress:\n\t <all pairwise comparisons for each plot finishes with '.'>\n")
	for(row in 1:l.plots) {
		cat(".")
		rr=plots[row]
		r=which(plots==rr)
		for(cc in plots[which(plots!=rr)]) {
			c=which(plots==cc)
			keep=plots[!is.na(match(plots, c(cc,rr)))]
			sp.rc=sp_plot[,keep]
			ss=spacodi.calc(sp_plot=sp.rc, phy=phy)
			class(ss)="vector"
			s.names=names(ss)
			for(xx in 1:length(ss)) {
				sp.array[r,c,xx]=unlist(unname(ss[which(names(ss)==names(ss)[xx])]))
			}
		}
		for(yy in 1:4) {
			foo=sp.array[r,,yy]
			out.array[r,1,yy]=sum(foo[which(!is.na(foo))])/(l.plots-1)
		}
	}
	cat("\n")
	for(zz in 1:4) {
		foo=as.data.frame(out.array[,,zz])
		row.names(foo)=plots
		d.matrix=dist(foo)
		r.out[[zz]]=d.matrix
	}
	names(r.out)=c("Ist","Pst","Bst","PIst")
	return(r.out)
}